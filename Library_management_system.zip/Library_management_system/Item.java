import java.util.ArrayList;

class Item{
    private int itemId;
    private String title;
    private int publicationYear;
    private boolean availableStatus;
    private ArrayList<Item> items;
    
    Item(int itemId, String title, int publicationYear, boolean availableStatus){
        this.availableStatus = availableStatus;
        this.itemId = itemId;
        this.publicationYear = publicationYear;
        this.title = title;
    }

    void addItem(){};
    public Item searchItem(int itemId) {
        for (Item item : items) {
            if (item.getItemId() == itemId) {
                return item;
            }
        }
        return null;
    }
    void displayAllItems(){};
    void issueItem(){};
    void returnItem(){};
    void displayDetails(){};

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public boolean isAvailableStatus() {
        return availableStatus;
    }

    public void setAvailableStatus(boolean availableStatus) {
        this.availableStatus = availableStatus;
    }

    public ArrayList<Item> getItems() {
        return items;
    }

    public void setItems(ArrayList<Item> items) {
        this.items = items;
    }

}