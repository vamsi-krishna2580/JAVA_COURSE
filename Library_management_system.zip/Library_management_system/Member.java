public class Member {
    void getMemberId(){};
    void getMemberName(){};
    void dispalyDetails(){};
}
