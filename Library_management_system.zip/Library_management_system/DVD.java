public class DVD extends Item {
    private int Duration;
    private String Genre;
    
    DVD(int itemId, String title, int publicationYear, boolean availableStatus, int Duration, String Genre){
        super(itemId, title, publicationYear, availableStatus);
        this.Duration = Duration;
        this.Genre = Genre;
    }
}
