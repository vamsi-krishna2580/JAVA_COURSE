public class Magazine extends Item {
    private int Issue_Number;
    private String publication_month;

    Magazine(int itemId, String title, int publicationYear, boolean availableStatus, int Issue_number, String publication_month){
        super(itemId, title, publicationYear, availableStatus);
        this.Issue_Number = Issue_Number;
        this.publication_month = publication_month;
    }
}
