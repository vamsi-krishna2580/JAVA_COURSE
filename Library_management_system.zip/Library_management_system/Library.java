import java.util.ArrayList;

public class Library {
    private ArrayList<Item> items;
    private ArrayList<Member> members;
    private ArrayList<IssueRecord> issuedItems;

    void addItem(Item item){
        items.add(item);
    };
    void addMember(Member member){
        members.add(member);
    };
    void displayAllItems(){};
    void searchItem(){};
    void searchMember(){};
}
